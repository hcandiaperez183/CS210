#include <iostream>  // Include the necessary header file for input/output operations

// Developer: Haley Candia Perez
// Date: 03/10/2024
// Purpose: Output the message "Hello, World!" to the console.

int main() {
    // Print the message "Hello, World!" to the console
    std::cout << "Hello, World!" << std::endl;

    // Return 0 to indicate successful execution to the operating system
    return 0;
}