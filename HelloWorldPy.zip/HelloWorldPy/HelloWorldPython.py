
# Developer: Haley Candia Perez
# Date: 03/10/2024
# Purpose: This Python program prints the message "Hello, World!" to the console.

# Print the message "Hello, World!" to the console using the print function.
print("Hello, World!")